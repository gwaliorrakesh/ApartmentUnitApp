package com.apartment.demo;



import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApartmentUnitApp {

	public static void main(String[] args) {
		SpringApplication.run(ApartmentUnitApp.class, args);
	}

}
