package com.apartment.demo.model;

import java.io.Serializable;

public class ResidentDetails implements Serializable{

	@Override
	public String toString() {
		return "ResidentDetails: {residentId:" + residentId + ", nameOfResident:" + nameOfResident + ", typeOfResident:"
				+ typeOfResident + ", houseArea:" + houseArea + "}";
	}
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int residentId;
	private String nameOfResident;
	private String typeOfResident;
	private String houseArea;

	public int getResidentId() {
		return residentId;
	}
	public void setResidentId(int residentId) {
		this.residentId = residentId;
	}
	public String getNameOfResident() {
		return nameOfResident;
	}
	public void setNameOfResident(String nameOfResident) {
		this.nameOfResident = nameOfResident;
	}
	public String getTypeOfResident() {
		return typeOfResident;
	}
	public void setTypeOfResident(String typeOfResident) {
		this.typeOfResident = typeOfResident;
	}
	public String getHouseArea() {
		return houseArea;
	}
	public void setHouseArea(String houseArea) {
		this.houseArea = houseArea;
	}


}
