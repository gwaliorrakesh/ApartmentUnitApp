package com.apartment.demo.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.apartment.demo.model.ApartmentUnits;
import com.apartment.demo.model.MaintenancePayment;
import com.apartment.demo.model.ResidentDetails;

@RestController
@RequestMapping("myapartment")
public class MainContoller {
	
	@RequestMapping("getmaintdetails")
	public ResponseEntity<ApartmentUnits> getMainDetails() {
		ApartmentUnits apartment = getApartmentValues();
		return new ResponseEntity<ApartmentUnits>(apartment,HttpStatus.OK);
		
	}
	
	private ApartmentUnits getApartmentValues() {
		ApartmentUnits apartment = new ApartmentUnits();
		
		apartment.setApartmentId(1);
		
		ResidentDetails residentDetails = new ResidentDetails();
		apartment.setResidentDetails(residentDetails);
		
		MaintenancePayment maintenancePayment = new MaintenancePayment();
		apartment.setMaintenancePayment(maintenancePayment);
		
		return apartment;
	}

	@RequestMapping("getResidentdetails")
	public ResponseEntity<ResidentDetails> getResidentdetails() {
		return new ResponseEntity<ResidentDetails>(getResidentDetails(),HttpStatus.OK);
		
	}

	private ResidentDetails getResidentDetails() {
		ResidentDetails residentDetails = new ResidentDetails();
		return residentDetails;
	}
}
