package com.apartment.demo.model;

import java.io.Serializable;
import java.util.Date;

public class MaintenancePayment implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int rowId;
	private double maintenanceCost;
	private Date pendingDate;
	private double fine;

	@Override
	public String toString() {
		return "MaintenancePayment :{rowId:" + rowId + ", maintenanceCost:" + maintenanceCost + ", pendingDate:"
				+ pendingDate + ", fine:" + fine + "}";
	}

	public double getMaintenanceCost() {
		return maintenanceCost;
	}

	public void setMaintenanceCost(double maintenanceCost) {
		this.maintenanceCost = maintenanceCost;
	}

	public Date getPendingDate() {
		return pendingDate;
	}

	public void setPendingDate(Date pendingDate) {
		this.pendingDate = pendingDate;
	}

	public double getFine() {
		return fine;
	}

	public void setFine(double fine) {
		this.fine = fine;
	}

	public int getRowId() {
		return rowId;
	}

	public void setRowId(int rowId) {
		this.rowId = rowId;
	}
}
