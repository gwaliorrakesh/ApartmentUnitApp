package com.apartment.demo.model;

import java.io.Serializable;

public class ApartmentUnits implements Serializable{
	@Override
	public String toString() {
		return "ApartmentUnits : {apartmentId:" + apartmentId + ", residentDetails:" + residentDetails
				+ ", maintenancePayment:" + maintenancePayment + "}";
	}
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int apartmentId;
	private ResidentDetails residentDetails;
	private MaintenancePayment maintenancePayment;
	
	
	public MaintenancePayment getMaintenancePayment() {
		return maintenancePayment;
	}
	public void setMaintenancePayment(MaintenancePayment maintenancePayment) {
		this.maintenancePayment = maintenancePayment;
	}
	public ResidentDetails getResidentDetails() {
		return residentDetails;
	}
	public void setResidentDetails(ResidentDetails residentDetails) {
		this.residentDetails = residentDetails;
	}
	public int getApartmentId() {
		return apartmentId;
	}
	public void setApartmentId(int apartmentId) {
		this.apartmentId = apartmentId;
	}
	
}
