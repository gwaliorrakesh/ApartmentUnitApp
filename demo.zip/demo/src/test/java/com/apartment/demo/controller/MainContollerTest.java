package com.apartment.demo.controller;

import org.junit.jupiter.api.Test;
import org.springframework.web.client.RestTemplate;

import com.apartment.demo.model.ApartmentUnits;
import com.apartment.demo.model.ResidentDetails;

class MainContollerTest {

	@Test
	void testGetMainDetails() {
		
		RestTemplate restTemplate = new RestTemplate();
		ApartmentUnits apartmentUnits = restTemplate.getForObject("http://localhost:8081/myapartment/getmaintdetails", ApartmentUnits.class);
		System.out.println("getMainDetails api response : "+apartmentUnits); 
		//fail("Not yet implemented");
	}

	@Test
	void testGetResidentdetails() {
		
		RestTemplate restTemplate = new RestTemplate();
		ResidentDetails residentDetails = restTemplate.getForObject("http://localhost:8081/myapartment/getResidentdetails", ResidentDetails.class);
		System.out.println("getResidentdetails api response : "+residentDetails); 
		//fail("Not yet implemented");
	}

}
